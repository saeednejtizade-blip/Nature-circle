NATURE CIRCLE V1 — BUILD APK FROM PHONE

This package is prepared so GitHub Actions can build the Android APK for you.
You do NOT need Windows or Android Studio on your phone.

PHONE STEPS
1. On GitHub, create a new repository (for example: nature-circle-app).
2. Open the repository.
3. Upload the file: nature_circle_source.zip
4. Create this file path in GitHub:
   .github/workflows/build-apk.yml
   Paste the contents of the included build-apk.yml into it and commit.
5. Open the repository's Actions tab.
6. Open "Build Nature Circle APK".
7. Tap "Run workflow" and run it.
8. Wait for the green checkmark.
9. Open the completed workflow run.
10. In Artifacts, download "Nature-Circle-V1-APK".
11. Extract the downloaded artifact and install app-debug.apk on your Android phone.

IMPORTANT
- This is a DEBUG APK, signed automatically by the Android build system for testing.
- The current app is a UI/prototype build. Real server-side authentication, hashed passwords,
  invitation-code persistence/revocation, push notifications, audit logging, etc. require a backend.
- The source archive is based on the current Nature Circle V1 Android wrapper/preview.
